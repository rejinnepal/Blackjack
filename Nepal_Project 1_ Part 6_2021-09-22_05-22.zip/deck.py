def card_name(card_rank):

  if card_rank == 1:
    to_return = 'Ace'
  elif card_rank == 11:
    to_return = 'Jack'
  elif card_rank == 12:
    to_return = 'Queen'
  elif card_rank == 13:
    to_return = 'King'
  else:
    to_return = str(card_rank)
  return to_return

def card_value(card_rank):
  
  if card_rank == 1:
    to_return = 11
  elif card_rank == 11:
    to_return = 10
  elif card_rank == 12:
    to_return = 10
  elif card_rank == 13:
    to_return = 10
  else:
    to_return = card_rank
  return to_return

def end_turn_status(hand):
  if hand < 21:
    to_return = ""
  elif hand == 21:
    to_return = "BLACKJACK!"
  elif hand > 21:
    to_return = "BUST."
  return to_return

def end_game_status(user_hand, dealer_hand):
  
  if dealer_hand <= 21 and (dealer_hand > user_hand or user_hand > 21):
    to_return = "Dealer wins!"
  elif user_hand <= 21 and (user_hand > dealer_hand or dealer_hand > 21):
    to_return = "You win!"
  else:
    to_return = "Tie."
  return to_return
    